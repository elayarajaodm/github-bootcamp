const Employee = require('./../models/employee');
exports.getdefault = function(req, res){
    res.send('You are on the root route, from controller.');
  };
  //
  exports.aboutus=function(req, res){
    res.send('You are on the about us route.');
  };
  //
  exports.addemployee = function(req, res){ 
    let empName = req.body.empName;
    let empPass = req.body.empPasse
    const Emp = new Employee();
    Emp.empName = empName;
    Emp.empPass = empPass;
    Emp.save()
    .then(msg => res.send({"message": "Created " + Emp.empName}))
    .catch(err => {console.log("Error in addemployee")});
    //res.end(`POST success, you sent ${empName} and ${empPass}, thanks!`);
  };
  //
  exports.getemployees=function(req, res){
    Employee.find({})
    .then((employeeData)=>{
      res.send(employeeData);
    })
    .catch(
      err => res.send(err)
    );
    //res.send('You are on the getemployees route.');
  };
//
exports.updateemployee = function(req, res){ 
  let empName = req.body.empName;
  let newPass = req.body.newPass;
  let empToFind = empName;
  Employee.findOneAndUpdate(
    {empName:empToFind},
    {$set:{ empPass: newPass}},
    {new : true}
  )
  .then(
    result=>{
    if(!result)
      res.send({message:empName + " was not updated!"});
    else 
      res.send({message:"Updated " + empName});
    })
  .catch(
    (err) => {
      res.send({message : "Update Failed " + err.message})
    }
  );
};
  //